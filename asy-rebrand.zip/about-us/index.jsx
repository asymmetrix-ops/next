import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header69 } from "./components/Header69";
import { Layout37 } from "./components/Layout37";
import { Logo3 } from "./components/Logo3";
import { Cta13 } from "./components/Cta13";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header69 />
      <Layout37 />
      <Logo3 />
      <Cta13 />
      <Footer1 />
    </div>
  );
}
