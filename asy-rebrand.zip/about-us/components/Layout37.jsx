"use client";

import React from "react";

export function Layout37() {
  return (
    <section id="relume" className="relative px-[5%] py-16 md:py-24 lg:py-28">
      <div className="container relative z-10">
        <div className="w-full max-w-md">
          <p className="mb-3 font-semibold text-text-alternative md:mb-4">
            Values
          </p>
          <h2 className="mb-5 text-5xl font-bold text-text-alternative md:mb-6 md:text-7xl lg:text-8xl">
            At Asymmetrix, we are building company that prioritises innovation
            and growth whilst still working for everybody.
          </h2>
          <p className="text-text-alternative md:text-md">
            Never stop learning Be client-centric See a problem, fix a problem
            Reflect on your own actions Give your health the attention it
            deserves
          </p>
        </div>
      </div>
      <div className="absolute inset-0 z-0">
        <img
          src="https://d22po4pjz3o32e.cloudfront.net/placeholder-image.svg"
          className="size-full object-cover"
          alt="Relume placeholder image"
        />
        <div className="absolute inset-0 bg-black/50" />
      </div>
    </section>
  );
}
