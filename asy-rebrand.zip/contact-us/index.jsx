import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header64 } from "./components/Header64";
import { Contact6 } from "./components/Contact6";
import { Cta14 } from "./components/Cta14";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header64 />
      <Contact6 />
      <Cta14 />
      <Footer1 />
    </div>
  );
}
