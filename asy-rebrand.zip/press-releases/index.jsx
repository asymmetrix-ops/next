import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Blog34 } from "./components/Blog34";
import { Blog32 } from "./components/Blog32";
import { Cta13 } from "./components/Cta13";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Blog34 />
      <Blog32 />
      <Cta13 />
      <Footer1 />
    </div>
  );
}
