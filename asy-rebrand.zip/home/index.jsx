import React from "react";
import { Navbar1 } from "./components/Navbar1";
import { Header114 } from "./components/Header114";
import { Logo3 } from "./components/Logo3";
import { Layout184 } from "./components/Layout184";
import { Layout485 } from "./components/Layout485";
import { Logo3_1 } from "./components/Logo3_1";
import { Testimonial1 } from "./components/Testimonial1";
import { Blog16 } from "./components/Blog16";
import { Cta15 } from "./components/Cta15";
import { Footer1 } from "./components/Footer1";

export default function Page() {
  return (
    <div>
      <Navbar1 />
      <Header114 />
      <Logo3 />
      <Layout184 />
      <Layout485 />
      <Logo3_1 />
      <Testimonial1 />
      <Blog16 />
      <Cta15 />
      <Footer1 />
    </div>
  );
}
